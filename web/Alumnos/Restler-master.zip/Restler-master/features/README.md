# features
### home for BDD

Behaviour Driven Development starts here. The classes that are used to do the 
tests are located under `bootstrap` folder. Remaining folders contain the tests

You may run the following command to run the tests

    bit/behat
