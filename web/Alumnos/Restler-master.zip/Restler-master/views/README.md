# views
### home for the restler view files

When HtmlFormat is used, it looks into this folder for view (template) files